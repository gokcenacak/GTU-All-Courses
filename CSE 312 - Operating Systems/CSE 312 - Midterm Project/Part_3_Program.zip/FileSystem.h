#ifndef FILE_SYSTEM_H_
#define FILE_SYSTEM_H_

#include "SingleIndirectBlock.h"
#include "DoubleIndirectBlock.h"
#include "TripleIndirectBlock.h"
#include "DataBlock.h"
#include "DirectoryBlock.h"
#include "Superblock.h"
#include <vector>
#include <stdlib.h>
#include <fstream>
#include <iostream>


class Superblock;
class Inode;
class DirectoryBlock;
class DataBlock;
class SingleIndirectBlock;
class DoubleIndirectBlock;
class TripleIndirectBlock;

class FileSystem
{
public:
	static FileSystem* get();
	SingleIndirectBlock * getSIBlock(int addr);
	DoubleIndirectBlock * getDIBlock(int addr);
	TripleIndirectBlock * getTIBlock(int addr);
	DataBlock * getDataBlock(int addr);
	Inode * getInode(int addr);
	DirectoryBlock * getDirectoryBlock(int addr);
	Superblock * getSuperblock() { return superBlock; }
	void initialize(int blockSize, int freeINodeCount);
	void writeToDisk(char * fileName);
	void readFromDisk(char * fileName);
	void dumpe2fs();
	void mkdir(char * path);
	void list(char * path);
	void write(char * path, char * fileName);
	void read(char * path, char *fileName);
	void rmdir(char * path);
	void del(char * path);
private:
	static FileSystem* instance;
	FileSystem();
	~FileSystem();
	std::vector<SingleIndirectBlock> SIBlocks;
	std::vector<DoubleIndirectBlock> DIBlocks;
	std::vector<TripleIndirectBlock> TIBlocks;
	std::vector<DataBlock> dataBlocks;
	std::vector<Inode> iNodes;
	std::vector<DirectoryBlock> directoryBlocks;
	Superblock * superBlock;
	
	
};

#endif