#ifndef ATTRIBUTE_H_
#define ATTRIBUTE_H_

#include <cstring>
#include <time.h>
#include <vector>
#include "Utils.h"
#include "INodeType.h"
class Attribute
{
public:

	Attribute();
	~Attribute();

	//Setters
	inline void setSize(int newSize)   			{ size = newSize; }
	inline void setLastModification(time_t time) 	{ lastModification = time; }
	inline void setName(char * newName){
		for(int i=0 ; i<50 ; i++){
			name[i] = newName[i];
		}
	}
	inline void setIsFree(bool freeStatus) 			{ isFree = freeStatus; }
	inline void setInodeNum(int num) 				{ iNodeNum = num; }
	inline void setLinkCount(int count) 			{ linkCount = count; }
	inline void setINodeType(INodeType newType)			{ type = newType; }

	//Getters
	inline int getInodeNum() 	 		 	{ return iNodeNum; }
	inline int getLinkCount() 			 	{ return linkCount; }
	inline bool getIsFree() 			 	{ return isFree; }
	inline int getSize() 			 	{ return size; }
	inline time_t getLastModification()		{ return lastModification; }
	inline char * getName() 		 		{ return name; }
	inline INodeType getINodeType()				{ return type; }

	void clear();

	std::vector<unsigned char> toByteArray();	

private:
	INodeType type; 
	int iNodeNum;
	int linkCount;
	bool isFree;
	int size;
	time_t lastModification;
	char name[50];

};

#endif