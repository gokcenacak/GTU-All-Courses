#ifndef INODETYPE_H_
#define INODETYPE_H_

enum class INodeType { Directory, File, Free};

#endif