#ifndef TRIPLEINDIRECTBLOCK_H_
#define TRIPLEINDIRECTBLOCK_H_

#include "FileSystem.h"
#include "Utils.h"
#include <vector>
class TripleIndirectBlock
{
public:
	TripleIndirectBlock();
	~TripleIndirectBlock() {}
	inline int getDIBlock1Addr() { return DIBlock1Addr; }
	inline int getDIBlock2Addr() { return DIBlock2Addr; }
	inline bool getIsFree()		 { return isFree; }
	inline void setIsFree(bool freeCond) { isFree = freeCond;}
	void initialize(int addr1, int addr2);
	std::vector<unsigned char> convertToByteArray();
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	void print();
public:
	int DIBlock1Addr;
	int DIBlock2Addr;
	bool isFree;
};
#endif

