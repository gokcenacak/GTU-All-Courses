#ifndef SUPERNODE_H_
#define SUPERNODE_H_
#include <iostream>
#include <cmath>
#include <vector>
#include "Utils.h"
#include "FileSystem.h"
class Superblock{
	public: 
		Superblock(); 
		~Superblock();

		inline void setDirectoryCount(int count)			{ currentDirectoryCount = count;}
		inline void setFileCount(int count)					{ currentFileCount = count; }

		inline void setFreeDataBlockCount(int count) 		{ freeDataBlockCount = count; }
		inline void setFreeDirectoryBlockCount(int count) 	{ freeDirectoryBlockCount = count; }
		inline void setFreeSIBlockCount(int count)			{ freeSIBlockCount = count; }
		inline void setFreeDIBlockCount(int count)			{ freeDIBlockCount = count; }
		inline void setFreeTIBlockCount(int count)			{ freeTIBlockCount = count; }
		inline void setFreeINodeCount(int count) 	 		{ freeINodeCount = count; }
		inline void setMaxINodeCount(int count)				{ maxINodeCount = count; }

		inline int getBlockSize() 				{ return blockSize; }
		inline int getMaxINodeCount() 			{ return maxINodeCount; }
		inline int getMaxFileCount() 			{ return maxFileCount; }
		inline int getMaxDirectoryCount() 		{ return maxDirectoryCount; }
		inline int getMaxSIBlockCount() 		{ return maxSIBlockCount; }
		inline int getMaxDIBlockCount() 		{ return maxDIBlockCount; }
		inline int getMaxTIBlockCount() 		{ return maxTIBlockCount; }
		inline int getMaxDirectoryBlockCount() 	{ return maxDirectoryBlockCount; }
		inline int getMaxDataBlockCount() 		{ return maxDataBlockCount; }

		inline int getMaxFileSize() 			{ return maxFileSize; }
		inline int getMaxDirectorySize() 		{ return maxDirectorySize; }

		inline int getINodeStartPos() 			{ return iNodeStartPos; }
		inline int getDirectoryBlockStartPos()	{ return directoryBlockStartPos; }
		inline int getDataBlockStartPos()		{ return dataBlockStartPos; }
		inline int getSIBlockStartPos()			{ return SIBlockStartPos; }
		inline int getDIBlockStartPos()			{ return DIBlockStartPos; }
		inline int getTIBlockStartPos()			{ return TIBlockStartPos;}

		inline int getFreeDataBlockCount()		{ return freeDataBlockCount; }
		inline int getFreeDirectoryBlockCount()	{ return freeDirectoryBlockCount; }
		inline int getFreeSIBlockCount()		{ return freeSIBlockCount; }
		inline int getFreeDIBlockCount()		{ return freeDIBlockCount; }
		inline int getFreeTIBlockCount()		{ return freeTIBlockCount; }
		inline int getFreeINodeCount()			{ return freeINodeCount;}

		inline int getDirectoryCount()			{ return currentDirectoryCount; }
		inline int getFileCount()				{ return currentFileCount; }
		inline int getMaxDirectoryEntryPerDirectoryBlock()	{ return maxDirectoryEntryPerDirectoryBlock; }
		//inline int getDiskPaddingSize()			{ return diskPaddingSize; }

		void print();
		void initialize(int blockSize, int freeINodeCount);
		void convertFromByteArray(std::vector<unsigned char> byteArray);
		std::vector<unsigned char> convertToByteArray();
		
	private:
		int magicNumber;
		int blockSize;
		int maxINodeCount;
		int maxFileCount;
		int maxDirectoryCount;
		int maxSIBlockCount;
		int maxDIBlockCount;
		int maxTIBlockCount;
		int maxDirectoryBlockCount;
		int maxDataBlockCount;

		int maxFileSize;
		int maxDirectorySize;

		int iNodeStartPos;
		int directoryBlockStartPos;
		int dataBlockStartPos;
		int SIBlockStartPos;
		int DIBlockStartPos;
		int TIBlockStartPos;

		int freeDataBlockCount;
		int freeDirectoryBlockCount;
		int freeSIBlockCount;
		int freeDIBlockCount;
		int freeTIBlockCount;
		int freeINodeCount;

		int currentFileCount;
		int currentDirectoryCount;

		int maxDirectoryEntryPerDirectoryBlock;
		//int diskPaddingSize;


};
#endif

