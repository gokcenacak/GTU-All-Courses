#include "FileSystem.h"
#include <iostream>
int main(int argc, char const *argv[]) {
	if(argc < 3){
		std::cout << "Usage: fileSystemOper <diskFileName> <operation> <parameters>" << std::endl;
		return -1;
	}
	char diskFileName[50];
	strcpy(diskFileName,argv[1]);

	char operation[50];
	strcpy(operation,argv[2]);

	char fileName[50];
	FileSystem *fs = FileSystem::get();
	fs->readFromDisk(diskFileName);

	char path[50];

	if (strcmp(operation, "mkdir") == 0) {
		if (argc == 4) {
			strcpy(path, argv[3]);
			fs->mkdir(path);
			fs->writeToDisk(diskFileName);

		}
		else{
			std::cout << "Usage: fileSystemOper <diskFileName> mkdir <path>" << std::endl;
		}
	}
	else if(strcmp(operation, "list") == 0){
		if(argc == 4){
			strcpy(path, argv[3]);
			fs->list(path);
		}
		else{
			std::cout << "Usage: fileSystemOper <diskFileName> list <path>" << std::endl;
		}
	}
	else if(strcmp(operation, "write") == 0){
		if(argc == 5){
			strcpy(path, argv[3]);
			strcpy(fileName, argv[4]);
			fs->write(path, fileName);
			fs->writeToDisk(diskFileName);
		}
		else{
			std::cout << "Usage: fileSystemOper <diskFileName> write <path> <fileName>" << std::endl;
		}
	}
	else if(strcmp(operation, "read") == 0){
		if(argc == 5){
			strcpy(path, argv[3]);
			strcpy(fileName, argv[4]);
			fs->read(path, fileName);
		}
		else{
			std::cout << "Usage: fileSystemOper <diskFileName> read <path> <fileName>" << std::endl;
		}
	}
	else if(strcmp(operation, "dumpe2fs") == 0){
		if(argc == 3){
			fs->dumpe2fs();
		}
		else{
			std::cout << "Usage: fileSystemOper <diskFileName> dumpe2fs" << std::endl;
		}
	}
	else if(strcmp(operation, "del") == 0){
		if(argc == 4){
			strcpy(path,argv[3]);
			fs->del(path);
			fs->writeToDisk(diskFileName);

		}
	}
	else if(strcmp(operation,"rmdir") == 0){
		if(argc == 4){
			strcpy(path,argv[3]);
			fs->rmdir(path);
			fs->writeToDisk(diskFileName);
		}
	}

	
	return 0;
}