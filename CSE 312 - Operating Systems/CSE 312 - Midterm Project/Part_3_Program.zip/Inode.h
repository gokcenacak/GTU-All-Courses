#ifndef INODE_H_
#define INODE_H_

#include <ctime>
#include <string>
#include "Attribute.h"
#include "FileSystem.h"
#include "INodeType.h"
#include <fstream>
#include <iostream>
class Inode
{
public:
	Inode(int iNodeNumber);
	~Inode();
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	void assign(char * fileName, INodeType type);
	void print();
	inline Attribute getAttributes() { return attributes; }
	inline Attribute * getAttributesRef() { return &attributes; }
	inline int getBlockPointer1() { return blockPointers[0]; }
	inline int getBlockPointer2() { return blockPointers[1]; }
	inline int getSIPointer() { return singleIndirectPointer; }
	inline int getDIPointer() { return doubleIndirectPointer; }
	inline int getTIPointer() { return tripleIndirectPointer; }
	std::vector<int> allBlockAddresses();
	void unassign();
private:
	Attribute attributes;
	int blockPointers[2];
	int singleIndirectPointer;
	int doubleIndirectPointer;
	int tripleIndirectPointer;
};
#endif

