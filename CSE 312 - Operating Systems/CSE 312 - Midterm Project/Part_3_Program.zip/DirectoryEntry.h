#ifndef DIRECTORY_ENTRY_H_
#define DIRECTORY_ENTRY_H_

#include <cstring>
#include <vector> 
#include "Utils.h"
#include "FileSystem.h"
class DirectoryEntry
{
public:

	DirectoryEntry();
	DirectoryEntry(char * fileName, int iNodeNumber);
	~DirectoryEntry();
	int getINodeNumber() { return iNodeNumber; }
	char * getFileName() { return fileName; }
	DirectoryEntry& operator=(const DirectoryEntry& entry);
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	void print();
	void clear();
private:
	char fileName[50];
	int iNodeNumber;
};

#endif