#include "FileSystem.h"
#include "Inode.cpp"
#include "DirectoryBlock.cpp"

FileSystem* FileSystem::instance;

FileSystem::FileSystem() {
	// left intentionally empty
}

FileSystem::~FileSystem() {

}

FileSystem* FileSystem::get() {
	if (!instance) {
		instance = new FileSystem;
	}

	return instance;
}

void FileSystem::initialize(int blockSize, int freeINodeCount){
	superBlock = new Superblock();
	superBlock->initialize(blockSize, freeINodeCount);

	if  (superBlock->getMaxINodeCount() == 0 || 
		superBlock->getMaxSIBlockCount() < 7 ||
		superBlock->getMaxDIBlockCount() < 3 ||
	  	superBlock->getMaxTIBlockCount() < 1 ||
	  	superBlock->getMaxDirectoryBlockCount() < 16 ||
	  	superBlock->getMaxDataBlockCount() < 16){

		std::cout << "Given block size is too big to allocate all the resources needed for a single file/directory" << std::endl;
		exit(EXIT_FAILURE);
	}
	else{
		
		for (int i = 0; i < superBlock->getMaxINodeCount(); i++) {
			iNodes.push_back(Inode(i));	
		}

		SIBlocks.resize(superBlock->getMaxSIBlockCount());
		DIBlocks.resize(superBlock->getMaxDIBlockCount());
		TIBlocks.resize(superBlock->getMaxTIBlockCount());
		dataBlocks.resize(superBlock->getMaxDataBlockCount());
		directoryBlocks.resize(superBlock->getMaxDirectoryBlockCount());

		Inode * rootINode = getInode(0);
		char path[50] = "/";
		rootINode->assign(path, INodeType::Directory);

	}
}

void FileSystem::writeToDisk(char * fileName){
	std::vector<unsigned char> superBlockByteArray;
	std::vector<unsigned char> iNodesByteArray;
	std::vector<unsigned char> directoryBlocksByteArray;
	std::vector<unsigned char> dataBlocksByteArray;
	std::vector<unsigned char> SIBlocksByteArray;
	std::vector<unsigned char> DIBlocksByteArray;
	std::vector<unsigned char> TIBlocksByteArray;
	std::vector<unsigned char> diskByteArray;

	superBlockByteArray = superBlock->convertToByteArray();

	for(int i = 0 ; i < iNodes.size(); i++){
		for(auto& byte : iNodes[i].convertToByteArray()){
			iNodesByteArray.push_back(byte);
		}
	}

	for(int i = 0 ; i < directoryBlocks.size(); i++){
		for(auto& byte : directoryBlocks[i].convertToByteArray()){
			directoryBlocksByteArray.push_back(byte);
		}
	}

	for(int i = 0 ; i < dataBlocks.size(); i++){
		for(auto& byte : dataBlocks[i].convertToByteArray()){
			dataBlocksByteArray.push_back(byte);
		}
	}

	for(int i = 0 ; i < SIBlocks.size(); i++){
		for(auto& byte : SIBlocks[i].convertToByteArray()){
			SIBlocksByteArray.push_back(byte);
		}
	}

	for(int i = 0 ; i < DIBlocks.size(); i++){
		for(auto& byte : DIBlocks[i].convertToByteArray()){
			DIBlocksByteArray.push_back(byte);
		}
	}

	for(int i = 0 ; i < TIBlocks.size(); i++){
		for(auto& byte : TIBlocks[i].convertToByteArray()){
			TIBlocksByteArray.push_back(byte);
		}
	}

	for(auto& byte : superBlockByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : iNodesByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : directoryBlocksByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : dataBlocksByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : SIBlocksByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : DIBlocksByteArray){
		diskByteArray.push_back(byte);
	}
	for(auto& byte : TIBlocksByteArray){
		diskByteArray.push_back(byte);
	}

	int totalSize = superBlockByteArray.size()+
					iNodesByteArray.size() +
					directoryBlocksByteArray.size()+
					dataBlocksByteArray.size() +
	 				SIBlocksByteArray.size() +
					DIBlocksByteArray.size()+
					TIBlocksByteArray.size();

	for(int i = 0; i < 1048576 - totalSize; i++){
		diskByteArray.push_back('\0');
	}



	std::ofstream diskFile;
	diskFile.open(fileName,std::ios::binary);

	diskFile.write((char *)&diskByteArray[0],diskByteArray.size());
	
	diskFile.close();

}

void FileSystem::readFromDisk(char * fileName){
	std::vector<unsigned char> magicNumber;
	std::vector<unsigned char> blockSize;
	std::vector<unsigned char> freeINodeCount;
	std::vector<unsigned char> diskByteArray;
	std::vector<unsigned char> superBlockByteArray;
	std::vector<unsigned char> tempINodeByteArray;
	std::vector<unsigned char> tempDirectoryBlockByteArray;
	std::vector<unsigned char> tempDataBlockByteArray;
	std::vector<unsigned char> tempSIBlockByteArray;
	std::vector<unsigned char> tempDIBlockByteArray;
	std::vector<unsigned char> tempTIBlockByteArray;
	magicNumber.resize(4);
	blockSize.resize(4);
	freeINodeCount.resize(4);
	diskByteArray.resize(1024*1024);

	std::ifstream diskFile;
	diskFile.open(fileName,std::ios::binary);

	diskFile.read((char*)&magicNumber[0],4);
	int readMagicNumber = Utils::byteArrayToInt(magicNumber);

	diskFile.read((char*)&blockSize[0],4);
	int readBlockSize = Utils::byteArrayToInt(blockSize);

	diskFile.read((char*)&freeINodeCount[0],4);
	int readFreeINodeCount = Utils::byteArrayToInt(freeINodeCount);

	diskFile.close();

	if(readMagicNumber != 0xfee1dead){
		std::cout << "This is not a suitable disk file format for this system!" << std::endl;
	}
	else{
		initialize(readBlockSize, readFreeINodeCount);

		diskFile.open(fileName,std::ios::binary);
		diskFile.read((char*)&diskByteArray[0],1024*1024);
		int pos = 0;
		for(int i = pos; i < pos+readBlockSize*1024 ; i++){
			superBlockByteArray.push_back(diskByteArray[i]);
		}
		superBlock->convertFromByteArray(superBlockByteArray);
		pos+=readBlockSize*1024;
		for(int i = 0; i < superBlock->getMaxINodeCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024; j++){
				tempINodeByteArray.push_back(diskByteArray[j]);
			}
			iNodes[i].convertFromByteArray(tempINodeByteArray);
			pos+=readBlockSize*1024;
			tempINodeByteArray.clear();
		}

		for(int i = 0; i < superBlock->getMaxDirectoryBlockCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024; j++){
				tempDirectoryBlockByteArray.push_back(diskByteArray[j]);
			}
			directoryBlocks[i].convertFromByteArray(tempDirectoryBlockByteArray);
			pos+=readBlockSize*1024;
			tempDirectoryBlockByteArray.clear();
		}

		for(int i = 0 ; i < superBlock->getMaxDataBlockCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024; j++){
				tempDataBlockByteArray.push_back(diskByteArray[j]);
			}
			dataBlocks[i].convertFromByteArray(tempDataBlockByteArray);
			pos+=readBlockSize*1024;
			tempDataBlockByteArray.clear();
		}

		for(int i = 0; i < superBlock->getMaxSIBlockCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024 ; j++){
				tempSIBlockByteArray.push_back(diskByteArray[j]);
			}
			SIBlocks[i].convertFromByteArray(tempSIBlockByteArray);
			pos+=readBlockSize*1024;
			tempSIBlockByteArray.clear();
		}
		for(int i = 0; i < superBlock->getMaxDIBlockCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024 ; j++){
				tempDIBlockByteArray.push_back(diskByteArray[j]);
			}
			DIBlocks[i].convertFromByteArray(tempDIBlockByteArray);
			pos+=readBlockSize*1024;
			tempDIBlockByteArray.clear();
		}
		for(int i = 0; i < superBlock->getMaxTIBlockCount(); i++){
			for(int j = pos; j < pos+readBlockSize*1024 ; j++){
				tempTIBlockByteArray.push_back(diskByteArray[j]);
			}
			TIBlocks[i].convertFromByteArray(tempTIBlockByteArray);
			pos+=readBlockSize*1024;
			tempTIBlockByteArray.clear();
		}
	}
}

SingleIndirectBlock * FileSystem::getSIBlock(int addr){
	return &(SIBlocks[addr]);
}
DoubleIndirectBlock * FileSystem::getDIBlock(int addr){
	return &(DIBlocks[addr]);
}
TripleIndirectBlock * FileSystem::getTIBlock(int addr){
	return &(TIBlocks[addr]);
}
DataBlock * FileSystem::getDataBlock(int addr){
	return &(dataBlocks[addr]);
}
Inode * FileSystem::getInode(int addr){
	return &(iNodes[addr]);
}
DirectoryBlock * FileSystem::getDirectoryBlock(int addr){
	return &(directoryBlocks[addr]);
}

void FileSystem::dumpe2fs(){
	std::cout << "Block Count:\t\t\t\t\t" << superBlock->getMaxINodeCount() + superBlock->getMaxDirectoryBlockCount() + superBlock->getMaxDataBlockCount() + superBlock->getMaxSIBlockCount() + superBlock->getMaxDIBlockCount() + superBlock->getMaxTIBlockCount() + 1 <<std::endl;
	std::cout << "INode Count:\t\t\t\t\t" << superBlock->getMaxINodeCount() << std::endl;
	std::cout << "Free INode Count:\t\t\t\t" << superBlock->getFreeINodeCount() << std::endl;
	std::cout << "Free Directory Block Count:\t\t\t" << superBlock->getFreeDirectoryBlockCount() << std::endl;
	std::cout << "Free Data Block Count:\t\t\t\t" << superBlock->getFreeDataBlockCount() << std::endl;
	std::cout << "Free Single Indirect Block Count:\t\t" << superBlock->getFreeSIBlockCount() << std::endl;
	std::cout << "Free Double Indirect Block Count:\t\t" << superBlock->getFreeDIBlockCount() << std::endl;
	std::cout << "Free Triple Indirect Block Count:\t\t" << superBlock->getFreeTIBlockCount() << std::endl;
	std::cout << "File Count:\t\t\t\t\t" << superBlock->getFileCount() << std::endl;
	std::cout << "Directory Count:\t\t\t\t" << superBlock->getDirectoryCount() << std::endl;
	std::cout << "Block Size:\t\t\t\t\t" << superBlock->getBlockSize() << " KBs" << std::endl;
	std::cout << "Maximum File Count:\t\t\t\t" << superBlock->getMaxFileCount() << std::endl;
	std::cout << "Maximum Directory Count:\t\t\t" << superBlock->getMaxDirectoryCount() << std::endl;
	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FREE INODES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << std::endl;
	for(int i = 0 ; i < iNodes.size(); i++){
		if(iNodes[i].getAttributes().getINodeType() == INodeType::Free){
			iNodes[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>> FREE DIRECTORY BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < directoryBlocks.size(); i++){
		if(directoryBlocks[i].getIsFree() == true){
			std::cout << "----------------------------- Directory Block #" << i << " -----------------------------" << std::endl;
			directoryBlocks[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>>> FREE DATA BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < dataBlocks.size(); i++){
		if(dataBlocks[i].getIsFree() == true){
			std::cout << "----------------------------- Data Block #" << i << " -----------------------------" << std::endl;
			dataBlocks[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>> FREE SINGLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < SIBlocks.size(); i++){
		if(SIBlocks[i].getIsFree() == true){
			std::cout << "----------------------------- Single Indirect Block #" << i << " -----------------------------" << std::endl;
			SIBlocks[i].print(INodeType::Free);
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>> FREE DOUBLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < DIBlocks.size(); i++){
		if(DIBlocks[i].getIsFree() == true){
			std::cout << "----------------------------- Double Indirect Block #" << i << " -----------------------------" << std::endl;
			DIBlocks[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
	std::cout << ">>>>>>>>>>>>>>>>>>>>>>> FREE TRIPLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < TIBlocks.size(); i++){
		if(TIBlocks[i].getIsFree() == true){
			std::cout << "----------------------------- Triple Indirect Block #" << i << " -----------------------------" << std::endl;
			TIBlocks[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED INODES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << std::endl;
	for(int i = 0 ; i < iNodes.size(); i++){
		if(iNodes[i].getAttributes().getINodeType() != INodeType::Free){
			iNodes[i].print();
		}
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED DIRECTORY BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	int blockCount = 0;
	for(int i = 0 ; i < directoryBlocks.size(); i++){
		if(directoryBlocks[i].getIsFree() == false){
			std::cout << "----------------------------- Directory Block #" << i << " -----------------------------" << std::endl;
			std::string str(iNodes[blockCount/16].getAttributes().getName());
			std::cout << "Filename: " << str << std::endl;
			directoryBlocks[i].print();
		}
		blockCount++;

	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
	blockCount=0;
	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED DATA BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < dataBlocks.size(); i++){
		if(dataBlocks[i].getIsFree() == false){
			std::cout << "----------------------------- Data Block #" << i << " -----------------------------" << std::endl;
			std::string str(iNodes[blockCount/16].getAttributes().getName());
			std::cout << "Filename: " << str << std::endl;
			dataBlocks[i].print();
		}
		blockCount++;
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
	blockCount=0;
	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED SINGLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < SIBlocks.size(); i++){
		if(SIBlocks[i].getIsFree() == false){
			std::cout << "----------------------------- Single Indirect Block #" << i << " -----------------------------" << std::endl;
			std::string str(iNodes[blockCount/7].getAttributes().getName());
			INodeType type = iNodes[blockCount/7].getAttributes().getINodeType();
			std::cout << "Filename: " << str << std::endl;
			SIBlocks[i].print(type);
		}
		blockCount++;

	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
	blockCount=0;
	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED DOUBLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < DIBlocks.size(); i++){
		if(DIBlocks[i].getIsFree() == false){
			std::cout << "----------------------------- Double Indirect Block #" << i << " -----------------------------" << std::endl;
			std::string str(iNodes[blockCount/3].getAttributes().getName());
			std::cout << "Filename: " << str << std::endl;
			DIBlocks[i].print();
		}
		blockCount++;

	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
	blockCount=0;

	std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>> OCCUPIED TRIPLE INDIRECT BLOCKS <<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl;
	for(int i = 0 ; i < TIBlocks.size(); i++){
		if(TIBlocks[i].getIsFree() == false){
			std::cout << "----------------------------- Triple Indirect Block #" << i << " -----------------------------" << std::endl;
			std::string str(iNodes[blockCount].getAttributes().getName());
			std::cout << "Filename: " << str << std::endl;
			TIBlocks[i].print();
		}
		blockCount++;
	}
	std::cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" << std::endl << std::endl;
	
}

void FileSystem::mkdir(char * path){
	if(path[0] != '/'){
		std::cout << "Wrong path format" << std::endl;
		return;
	}
	if(superBlock->getDirectoryCount() == superBlock->getMaxDirectoryCount()){
		std::cout << "Cannot create more directories, limit is exceeded" << std::endl;
		return;
	}
	std::vector<std::string> directoryNames;
	std::string pathStr(path);
	std::string token;
	int pos = 0;
	while ((pos = pathStr.find("/")) != std::string::npos) {
	    token = pathStr.substr(0, pos);
	    directoryNames.push_back(token);
	    pathStr.erase(0, pos + 1);
	}
	directoryNames.push_back(pathStr);

	std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

	DirectoryEntry * target = nullptr;
	char str[50];
	for(int i = 0; i < directoryNames.size()-1; i++){
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,directoryNames[i].c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				target = de;
			}
		}
		if(target == nullptr){
			return;
		}
		blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
	}

	Inode * parentInode = &iNodes[target->getINodeNumber()];
	if(strcmp(parentInode->getAttributes().getName(), directoryNames[directoryNames.size()-2].c_str()) != 0 && directoryNames.size() != 2){
		std::cout << "Given path does not exists" << std::endl;
		return;
	}
	for(auto addr : parentInode->allBlockAddresses()){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,pathStr.c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				std::cout << "There is already a directory with the same name" << std::endl;
				return;				
			}
	}
	int i = 0;
	while(iNodes[i].getAttributes().getINodeType() != INodeType::Free){
		i++;
	}

	std::string directoryName = directoryNames[directoryNames.size()-1];
	strcpy(str,directoryName.c_str());

	iNodes[i].assign(str,INodeType::Directory);
	DirectoryEntry newDirEntry(str,i);

	parentInode->getAttributesRef()->setLastModification(time(NULL));
	bool added = false;
	blockAddresses = parentInode->allBlockAddresses();
	for(auto addr : blockAddresses){
		DirectoryBlock * db = getDirectoryBlock(addr);
		added = db->addEntry(newDirEntry);
		if(added){
			break;
		}
	}	
}

void FileSystem::list(char * path){
	if(strcmp(path,"/") == 0){
		std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			std::vector<DirectoryEntry> dirEntries = db->getDirectoryEntries();
			for(int i = 0; i < db->getDirEntriesSize() ; i++){
				int iNodeNum = dirEntries[i].getINodeNumber();
				Inode * inode = &iNodes[iNodeNum];
				if(iNodeNum == -1 || iNodeNum == 0) {
					continue;
				}
				std::string name(inode->getAttributes().getName());
				time_t lastModified = inode->getAttributes().getLastModification();
				int size = inode->getAttributes().getSize();
				if(inode->getAttributes().getIsFree() == false) {
					std::cout << name <<  " " << size << " " << asctime(localtime(&lastModified));
				}
			}
		}
	}
	else{
		std::vector<std::string> directoryNames;
		std::string pathStr(path);
		std::string token;
		int pos = 0;
		while ((pos = pathStr.find("/")) != std::string::npos) {
		    token = pathStr.substr(0, pos);
		    directoryNames.push_back(token);
		    pathStr.erase(0, pos + 1);
		}
		directoryNames.push_back(pathStr);

		std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

		DirectoryEntry * target = nullptr;
		char str[50];
		for(int i = 0; i < directoryNames.size(); i++){
			for(auto addr : blockAddresses){
				DirectoryBlock * db = getDirectoryBlock(addr);
				strcpy(str,directoryNames[i].c_str());
				DirectoryEntry * de = db->findDirectoryEntry(str);
				if(de != nullptr && strcmp(de->getFileName(),str)==0){
					target = de;
				}
			}
			if(target == nullptr){
				return;
			}
			blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
		}

		if(strlen(target->getFileName()) == 0) {
			std::cout << "Directory does not exist!" << std::endl;
			return;		
		}

		Inode * parentInode = &iNodes[target->getINodeNumber()];

		blockAddresses = parentInode->allBlockAddresses();
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			std::vector<DirectoryEntry> dirEntries = db->getDirectoryEntries();
			for(int i = 0; i < db->getDirEntriesSize() ; i++){
				int iNodeNum = dirEntries[i].getINodeNumber();
				Inode * inode = &iNodes[iNodeNum];
				if(iNodeNum == -1 || iNodeNum == 0) {
					continue;
				}
				std::string name(inode->getAttributes().getName());
				time_t lastModified = inode->getAttributes().getLastModification();
				int size = inode->getAttributes().getSize();
				if(inode->getAttributes().getIsFree() == false)
					std::cout << name << " " << size << " " << asctime(localtime(&lastModified));
			}
		}

	}
}

void FileSystem::write(char * path, char * fileName){
	std::vector<std::string> directoryNames;
	std::string pathStr(path);
	std::string token;
	int pos = 0;
	while ((pos = pathStr.find("/")) != std::string::npos) {
	    token = pathStr.substr(0, pos);
	    directoryNames.push_back(token);
	    pathStr.erase(0, pos + 1);
	}
	directoryNames.push_back(pathStr);

	std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

	DirectoryEntry * target = nullptr;
	char str[50];
	for(int i = 0; i < directoryNames.size()-1; i++){
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,directoryNames[i].c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				target = de;
			}
		}
		if(target == nullptr){
			return;
		}
		blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
	}

	Inode * parentInode = &iNodes[target->getINodeNumber()];
	bool exists = false;
	for(auto addr : parentInode->allBlockAddresses()){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,pathStr.c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				exists = true;
			}
	}
	int i = 0;
	if(!exists){
		if(superBlock->getFileCount() == superBlock->getMaxFileCount()){
			std::cout << "Cannot create a new file maximum file count limit exceeded" << std::endl;
		}
		while(iNodes[i].getAttributes().getINodeType() != INodeType::Free){
			i++;
		}
		std::string directoryName = directoryNames[directoryNames.size()-1];
		strcpy(str,directoryName.c_str());

		iNodes[i].assign(str,INodeType::File);
		DirectoryEntry newDirEntry(str,i);

		parentInode->getAttributesRef()->setLastModification(time(NULL));
		bool added = false;
		blockAddresses = parentInode->allBlockAddresses();
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			added = db->addEntry(newDirEntry);
			if(added){
				break;
			}
		}	
	}
	std::ifstream file;
	file.open(fileName,std::ios::binary);
	file.seekg(0, std::ios::end);
	int fileLength = file.tellg();
	file.seekg(0, std::ios::beg);

	char fileContent[fileLength];

	file.read(fileContent, fileLength);

	blockAddresses = iNodes[i].allBlockAddresses();
	int writtenSize = 0;
	for(auto addr: blockAddresses){
		DataBlock * db = getDataBlock(addr);
		writtenSize += db->write(&fileContent[writtenSize],fileLength-writtenSize);
		if(writtenSize == fileLength){
			break;
		}
	}
	iNodes[i].getAttributesRef()->setSize(writtenSize);
	iNodes[i].getAttributesRef()->setLastModification(time(NULL));	
}

void FileSystem::read(char * path, char * fileName){

	std::vector<std::string> directoryNames;
	std::string pathStr(path);
	std::string token;
	int pos = 0;
	while ((pos = pathStr.find("/")) != std::string::npos) {
	    token = pathStr.substr(0, pos);
	    directoryNames.push_back(token);
	    pathStr.erase(0, pos + 1);
	}
	directoryNames.push_back(pathStr);

	std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

	DirectoryEntry * target = nullptr;
	char str[50];
	for(int i = 0; i < directoryNames.size()-1; i++){
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,directoryNames[i].c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				target = de;
			}
		}
		if(target == nullptr){
			return;
		}
		blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
	}

	Inode * parentInode = &iNodes[target->getINodeNumber()];
	bool exists = false;
	int iNodeNum;
	for(auto addr : parentInode->allBlockAddresses()){
		DirectoryBlock * db = getDirectoryBlock(addr);
		strcpy(str,pathStr.c_str());
		DirectoryEntry * de = db->findDirectoryEntry(str);
		if(de != nullptr && strcmp(de->getFileName(),str)==0){
			exists = true;	
			iNodeNum = de->getINodeNumber();		
		}
	}

	if(!exists){
		std::cout << "File does not exist, cannot read" << std::endl;
	}
	else{
		std::ofstream file;
		file.open(fileName,std::ios::binary);
		blockAddresses = iNodes[iNodeNum].allBlockAddresses();
		for(auto addr : blockAddresses){
			DataBlock *db = getDataBlock(addr);
			std::vector<unsigned char> data = db->getData();
			for(int i = 0 ; i < db->getOccupied(); i++){
				file << data[i];
			}
		}
	}
}

void FileSystem::rmdir(char * path){
	if(strcmp(path,"/") == 0){
		std::cout << "Root directory cannot be deleted" << std::endl;
 		return;
	}
	if(path[0] != '/'){
		std::cout << "Wrong path format" << std::endl;
		return;
	}
	std::vector<std::string> directoryNames;
	std::string pathStr(path);
	std::string token;
	int pos = 0;
	while ((pos = pathStr.find("/")) != std::string::npos) {
	    token = pathStr.substr(0, pos);
	    directoryNames.push_back(token);
	    pathStr.erase(0, pos + 1);
	}
	directoryNames.push_back(pathStr);

	std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

	DirectoryEntry * target = nullptr;
	char str[50];
	for(int i = 0; i < directoryNames.size()-1; i++){
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,directoryNames[i].c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				target = de;
			}
		}
		if(target == nullptr){
			return;
		}
		blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
	}

	Inode * parentInode = &iNodes[target->getINodeNumber()];
	bool exists = false;
	int iNodeNum;
	for(auto addr : parentInode->allBlockAddresses()){
		DirectoryBlock * db = getDirectoryBlock(addr);
		strcpy(str,pathStr.c_str());
		DirectoryEntry * de = db->findDirectoryEntry(str);
		if(de != nullptr && strcmp(de->getFileName(),str)==0){
			exists = true;
			iNodeNum = de->getINodeNumber();	
			if(iNodes[iNodeNum].getAttributes().getINodeType() == INodeType::Directory){
				for(auto blockAddr : iNodes[iNodeNum].allBlockAddresses()){
					if(directoryBlocks[blockAddr].getCurrentEntryCount() > 0){
						std::cout << "Requested directory is not empty, cannot delete" << std::endl;
						return;
					}
				}
				de->clear();
				iNodes[iNodeNum].unassign();
			}	
			else{
				std::cout << "Requested path does not contain a directory, cannot delete it." << std::endl;
				return;
			}
		}
	}
	if(!exists){
		std::cout << "Requested directory is not found, cannot delete it" << std::endl;
		return;
	}
}

void FileSystem::del(char * path){
	if(path[0] != '/'){
		std::cout << "Wrong path format" << std::endl;
		return;
	}
	std::vector<std::string> directoryNames;
	std::string pathStr(path);
	std::string token;
	int pos = 0;
	while ((pos = pathStr.find("/")) != std::string::npos) {
	    token = pathStr.substr(0, pos);
	    directoryNames.push_back(token);
	    pathStr.erase(0, pos + 1);
	}
	directoryNames.push_back(pathStr);

	std::vector<int> blockAddresses = iNodes[0].allBlockAddresses();

	DirectoryEntry * target = nullptr;
	char str[50];
	for(int i = 0; i < directoryNames.size()-1; i++){
		for(auto addr : blockAddresses){
			DirectoryBlock * db = getDirectoryBlock(addr);
			strcpy(str,directoryNames[i].c_str());
			DirectoryEntry * de = db->findDirectoryEntry(str);
			if(de != nullptr && strcmp(de->getFileName(),str)==0){
				target = de;
			}
		}
		if(target == nullptr){
			return;
		}
		blockAddresses = iNodes[target->getINodeNumber()].allBlockAddresses();		
	}

	Inode * parentInode = &iNodes[target->getINodeNumber()];
	bool exists = false;
	int iNodeNum;
	for(auto addr : parentInode->allBlockAddresses()){
		DirectoryBlock * db = getDirectoryBlock(addr);
		strcpy(str,pathStr.c_str());
		DirectoryEntry * de = db->findDirectoryEntry(str);
		if(de != nullptr && strcmp(de->getFileName(),str)==0){
			exists = true;
			iNodeNum = de->getINodeNumber();	
			if(iNodes[iNodeNum].getAttributes().getINodeType() == INodeType::File){
				db->setCurrentEntryCount(db->getCurrentEntryCount()-1);
				de->clear();
				iNodes[iNodeNum].unassign();
				return;
			}	
			else{
				std::cout << "Requested path does not contain a file, cannot delete it." << std::endl;
				return;
			}
		}
	}
	if(!exists){
		std::cout << "Requested file is not found, cannot delete it" << std::endl;
		return;
	}
}
