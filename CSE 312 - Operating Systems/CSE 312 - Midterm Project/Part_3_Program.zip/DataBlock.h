#ifndef DATABLOCK_H_
#define DATABLOCK_H_

#include <vector>
#include <iostream>
#include "FileSystem.h"
class DataBlock
{
public:

	DataBlock();
	~DataBlock() {}
	int write(char * data, int size);
	void print();
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	inline bool getIsFree()		{ return isFree; }
	inline void setIsFree(bool freeCond)	{ isFree = freeCond; }
	inline int getOccupied()	{return occupied;}
	inline std::vector<unsigned char> getData() { return data;}
	void reset();
private:
	int size;
	int occupied;
	bool isFull;
	bool isFree;
	std::vector<unsigned char> data;
};

#endif