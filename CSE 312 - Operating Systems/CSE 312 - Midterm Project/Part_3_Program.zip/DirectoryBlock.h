#ifndef DIRECTORY_BLOCK_H_
#define DIRECTORY_BLOCK_H_

#include "DirectoryEntry.h"
#include "FileSystem.h"
class DirectoryEntry;

class DirectoryBlock
{
public:
	DirectoryBlock();
	~DirectoryBlock();
	bool addEntry(DirectoryEntry entry);
	void removeEntry(DirectoryEntry * entry);
	void print();
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	inline bool getIsFree() { return isFree; }
	inline void setIsFree(bool freeCond) { isFree = freeCond; }
	DirectoryEntry * findDirectoryEntry(char * name);
	inline int getCurrentEntryCount() { return currentEntryCount;}
	inline std::vector<DirectoryEntry> getDirectoryEntries() { return dirEntries; }
	inline void setCurrentEntryCount(int count) {currentEntryCount = count;}
	inline int getDirEntriesSize() { return dirEntries.size(); }
	void reset();
private:
	std::vector<DirectoryEntry> dirEntries;
	int maxEntryCount;
	int currentEntryCount;
	bool isFull;
	bool isFree;
};
#endif



