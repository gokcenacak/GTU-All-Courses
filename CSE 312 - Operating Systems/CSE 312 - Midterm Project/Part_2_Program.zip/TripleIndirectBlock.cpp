#include "TripleIndirectBlock.h"
TripleIndirectBlock::TripleIndirectBlock(){
	isFree = true;
	DIBlock1Addr = -1;
	DIBlock2Addr = -1;
}
void TripleIndirectBlock::initialize(int addr1, int addr2){
	DIBlock1Addr = addr1;
	DIBlock2Addr = addr2;
	isFree = false;
}
std::vector<unsigned char> TripleIndirectBlock::convertToByteArray(){
	int totalBytes = 0;
	std::vector<unsigned char> content;
	for(auto& byte : Utils::intToByteArray(DIBlock1Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(DIBlock2Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(isFree)){
		content.push_back(byte);
		totalBytes++;
	}
	Superblock * sb = FileSystem::get()->getSuperblock();
	for(int i = 0 ; i < (1024*sb->getBlockSize())- totalBytes ; i++){
		content.push_back('\0');
	}
	return content;
}
void TripleIndirectBlock::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> DIBlock1AddrByteArray;
	std::vector<unsigned char> DIBlock2AddrByteArray;
	std::vector<unsigned char> isFreeByteArray;
	int pos = 0;
	for(int i = pos ; i < pos+4 ; i++){
		DIBlock1AddrByteArray.push_back(byteArray[i]);
	}
	DIBlock1Addr = Utils::byteArrayToInt(DIBlock1AddrByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		DIBlock2AddrByteArray.push_back(byteArray[i]);
	}
	DIBlock2Addr = Utils::byteArrayToInt(DIBlock2AddrByteArray);
	pos+=4;
	for(int i = pos ; i < pos+4 ; i++){
		isFreeByteArray.push_back(byteArray[i]);
	}

	isFree = Utils::byteArrayToInt(isFreeByteArray);

}

void TripleIndirectBlock::print(){
	std::cout << "Double Indirect Block Address 1: " << DIBlock1Addr << std::endl;
	std::cout << "Double Indirect Block Address 2: " << DIBlock2Addr << std::endl;
	std::cout << "Is Free: " << isFree << std::endl;
}