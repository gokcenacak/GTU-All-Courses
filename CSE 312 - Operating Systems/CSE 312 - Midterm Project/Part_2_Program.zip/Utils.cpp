#include "Utils.h"

std::vector<unsigned char> Utils::intToByteArray(int number){
    std::vector<unsigned char> result(4);
    int mask = 0xFF;
    for (int i = 0; i < 4; i++){
        result[3 - i] = (number >> (i * 8)) & mask;
    }
    return result;
}

int Utils::byteArrayToInt(std::vector<unsigned char> byteArray){
	int result = 0;
    for (int i = 0; i < 4; i++){
        result += (byteArray[i] << ((3-i) * 8));
    }
    return result;
}

