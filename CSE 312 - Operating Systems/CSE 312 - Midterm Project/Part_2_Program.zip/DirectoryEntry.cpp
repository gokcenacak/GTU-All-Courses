#include "DirectoryEntry.h"

DirectoryEntry::DirectoryEntry(){
}

DirectoryEntry::DirectoryEntry(char * fileName, int iNodeNumber){
	this->iNodeNumber = iNodeNumber;
	for(int i=0 ; i<50 ; i++){
		this->fileName[i] = fileName[i];
	}
}

DirectoryEntry::~DirectoryEntry(){
	
}

DirectoryEntry& DirectoryEntry::operator=(const DirectoryEntry& entry){
	if(this == &entry){
		return *this;
	}
	strcpy(this->fileName, entry.fileName);
	this->iNodeNumber = entry.iNodeNumber;

	return *this;
}
std::vector<unsigned char> DirectoryEntry::convertToByteArray(){
	Superblock *sb = FileSystem::get()->getSuperblock();
	std::vector<unsigned char> content;
	int totalBytes = 0;
	for(int i = 0; i < 50; i++){
		content.push_back(fileName[i]);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(iNodeNumber)){
		content.push_back(byte);
		totalBytes++;
	}
	
	return content;
}
void DirectoryEntry::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> iNodeNumberByteArray;
	int strPos = 0;
	int pos = 0;
	char name[50];
	for(int i = pos ; i < pos+50 ; i++, strPos++){
		name[strPos] = byteArray[i];
	}
	pos+=50;

	strcpy(fileName,name);

	for(int i = pos ; i < pos+4 ; i++){
		iNodeNumberByteArray.push_back(byteArray[i]);
	}
	iNodeNumber = Utils::byteArrayToInt(iNodeNumberByteArray);
}
void DirectoryEntry::print(){
	for(int i = 0 ; i < 50 ; i++){
		std::cout << fileName[i];
	}
	std::cout << " " << iNodeNumber << std::endl;
}

void DirectoryEntry::clear(){
	memset(fileName,0,50);
	iNodeNumber = -1;
}