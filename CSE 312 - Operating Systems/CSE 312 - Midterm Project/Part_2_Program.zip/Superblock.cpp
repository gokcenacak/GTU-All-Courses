#include "Superblock.h"

Superblock::Superblock(){
	
}
void Superblock::initialize(int blockSize, int freeINodeCount){
	this->magicNumber = 0xFEE1DEAD;
	this->blockSize = blockSize;

	//Maximum block, file, directory counts
	this->maxINodeCount = (1024-blockSize)/(28*blockSize); //1MB divided by the size of a total iNode - 1(the superblock)
	if(freeINodeCount >= maxINodeCount){
			std::cout << "With requested block size, system cannot allocate enough resources for requested Inode count" << std::endl;
			std::cout << "Allocating " << maxINodeCount << " Inodes with the requested block size..." << std::endl;			
	}
	
	this->maxINodeCount = freeINodeCount >= maxINodeCount ? maxINodeCount : freeINodeCount;
	this->maxFileCount = floor(maxINodeCount * 0.8); //80% of the inodes is files
	this->maxDirectoryCount = ceil(maxINodeCount * 0.2); //20% of the inodes is the directories
	this->maxSIBlockCount = maxINodeCount * 7;
	this->maxDIBlockCount = maxINodeCount * 3;
	this->maxTIBlockCount = maxINodeCount;
	this->maxDirectoryBlockCount = maxDirectoryCount * 16;
	this->maxDataBlockCount = maxFileCount * 16;

	//Maximum sizes
	this->maxFileSize = 16 * blockSize;
	this->maxDirectorySize = 16 * blockSize;

	//Starting positions
	this->iNodeStartPos = 1;
	this->directoryBlockStartPos = iNodeStartPos + maxINodeCount;
	this->dataBlockStartPos = directoryBlockStartPos + 16 * maxDirectoryCount;
	this->SIBlockStartPos = dataBlockStartPos + 16 * maxFileCount;
	this->DIBlockStartPos = SIBlockStartPos + 7 * maxINodeCount;
	this->TIBlockStartPos = DIBlockStartPos + 3 * maxINodeCount;

	//Free block counts
	this->freeDataBlockCount = maxDataBlockCount;
	this->freeDirectoryBlockCount = maxDirectoryBlockCount;
	this->freeSIBlockCount = maxSIBlockCount;
	this->freeDIBlockCount = maxDIBlockCount;
	this->freeTIBlockCount = maxTIBlockCount;
	this->freeINodeCount = maxINodeCount;

	this->currentFileCount = 0;
	this->currentDirectoryCount = 0;

	this->maxDirectoryEntryPerDirectoryBlock = (blockSize * 1024 - (4*sizeof(int))) / 54; //54=filename is 50 character long so 50 bytes, inode addr is integer so 4 bytes
}

void Superblock::print(){
	std::cout << "-----------------------SUPERBLOCK-----------------------" << std::endl;
	std::cout << "Maximum INode Count = " << maxINodeCount << std::endl;
	std::cout << "Maximum File Count = " << maxFileCount << std::endl;
	std::cout << "Maximum Directory Count = " << maxDirectoryCount << std::endl;
	std::cout << "Maximum Single Indirect Block Count = " << maxSIBlockCount << std::endl;
	std::cout << "Maximum Double Indirect Block Count = " << maxDIBlockCount << std::endl;
	std::cout << "Maximum Triple Indirect Block Count = " << maxTIBlockCount << std::endl;
	std::cout << "Maximum Directory Block Count = " << maxDirectoryBlockCount << std::endl;
	std::cout << "Maximum Data Block Count = " << maxDataBlockCount << std::endl;
	std::cout << "Maximum File Size = " << maxFileSize << " KBs" << std::endl;
	std::cout << "Maximum Directory Size = " << maxDirectorySize << " KBs" << std::endl;
	std::cout << "Maximum Directory Entry Per Directory Block = " << maxDirectoryEntryPerDirectoryBlock << std::endl;
	std::cout << "INode Starting Position = Address " << iNodeStartPos << " in the disk" << std::endl;
	std::cout << "Directory Blocks Starting Position = Address " << directoryBlockStartPos << " in the disk" << std::endl;
	std::cout << "Data Blocks Starting Position = Address " << dataBlockStartPos << " in the disk" << std::endl;
	std::cout << "Single Indirect Blocks Starting Position = Address " << SIBlockStartPos << " in the disk" << std::endl;
	std::cout << "Double Indirect Blocks Starting Position = Address " << DIBlockStartPos << " in the disk" << std::endl;
	std::cout << "Triple Indirect Blocks Starting Position = Address " << TIBlockStartPos << " in the disk" << std::endl;
	std::cout << "Free Data Block Count = " << freeDataBlockCount << std::endl;
	std::cout << "Free Directory Block Count = " << freeDirectoryBlockCount << std::endl;
	std::cout << "Free Single Indirect Block Count = " << freeSIBlockCount << std::endl;
	std::cout << "Free Double Indirect Block Count = " << freeDIBlockCount << std::endl;
	std::cout << "Free Triple Indirect Block Count = " << freeTIBlockCount << std::endl;
	std::cout << "Free INode Count = " << freeINodeCount << std::endl;
	std::cout << "Current File Count = " << currentFileCount << std::endl;
	std::cout << "Current Directory Count = " << currentDirectoryCount << std::endl;
	std::cout << "--------------------------------------------------------" << std::endl;


}

std::vector<unsigned char> Superblock::convertToByteArray(){
	Superblock * sb = FileSystem::get()->getSuperblock();
	std::vector<unsigned char> content;
	int totalBytes = 0;

	for (auto& byte : Utils::intToByteArray(magicNumber)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(blockSize)) {
		content.push_back(byte);	
		totalBytes++;	
	}
	for (auto& byte : Utils::intToByteArray(maxINodeCount)) {
		content.push_back(byte);	
		totalBytes++;	
	}
	for (auto& byte : Utils::intToByteArray(maxFileCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDirectoryCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxSIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxTIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDirectoryBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDataBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxFileSize)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDirectorySize)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(iNodeStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(directoryBlockStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(dataBlockStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(SIBlockStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(DIBlockStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(TIBlockStartPos)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeDataBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeDirectoryBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeSIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeDIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeTIBlockCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(freeINodeCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(currentFileCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(currentDirectoryCount)) {
		content.push_back(byte);
		totalBytes++;		
	}
	for (auto& byte : Utils::intToByteArray(maxDirectoryEntryPerDirectoryBlock)) {
		content.push_back(byte);
		totalBytes++;		
	}

	for(int i = 0 ; i < (1024*blockSize) - totalBytes ; i++){
		content.push_back('\0');
	}
	return content;
}

void Superblock::convertFromByteArray(std::vector<unsigned char> byteArray){
	int pos = 0;
	std::vector<unsigned char> magicNumberByteArray;
	std::vector<unsigned char> blockSizeByteArray;
	std::vector<unsigned char> maxINodeCountByteArray;
	std::vector<unsigned char> maxFileCountByteArray;
	std::vector<unsigned char> maxDirectoryCountByteArray;
	std::vector<unsigned char> maxSIBlockCountByteArray;
	std::vector<unsigned char> maxDIBlockCountByteArray;
	std::vector<unsigned char> maxTIBlockCountByteArray;
	std::vector<unsigned char> maxDirectoryBlockCountByteArray;
	std::vector<unsigned char> maxDataBlockCountByteArray;
	std::vector<unsigned char> maxFileSizeByteArray;
	std::vector<unsigned char> maxDirectorySizeByteArray;
	std::vector<unsigned char> iNodeStartPosByteArray;
	std::vector<unsigned char> directoryBlockStartPosByteArray;
	std::vector<unsigned char> dataBlockStartPosByteArray;
	std::vector<unsigned char> SIBlockStartPosByteArray;
	std::vector<unsigned char> DIBlockStartPosByteArray;
	std::vector<unsigned char> TIBlockStartPosByteArray;
	std::vector<unsigned char> freeDataBlockCountByteArray;
	std::vector<unsigned char> freeDirectoryBlockCountByteArray;
	std::vector<unsigned char> freeSIBlockCountByteArray;
	std::vector<unsigned char> freeDIBlockCountByteArray;
	std::vector<unsigned char> freeTIBlockCountByteArray;
	std::vector<unsigned char> freeINodeCountByteArray;
	std::vector<unsigned char> currentFileCountByteArray;
	std::vector<unsigned char> currentDirectoryCountByteArray;
	std::vector<unsigned char> maxDirectoryEntryPerDirectoryBlockByteArray;

	for(int i = pos ; i < pos+4 ; i++){
		magicNumberByteArray.push_back(byteArray[i]);
	}
	magicNumber = Utils::byteArrayToInt(magicNumberByteArray);
	pos+=4;

	for(int i = pos; i < pos+4 ; i++){
		blockSizeByteArray.push_back(byteArray[i]);
	}
	blockSize = Utils::byteArrayToInt(blockSizeByteArray);
	pos+=4;

	for(int i = pos; i < pos+4 ; i++){
		maxINodeCountByteArray.push_back(byteArray[i]);
	}
	maxINodeCount = Utils::byteArrayToInt(maxINodeCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxFileCountByteArray.push_back(byteArray[i]);
	}
	maxFileCount = Utils::byteArrayToInt(maxFileCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDirectoryCountByteArray.push_back(byteArray[i]);
	}
	maxDirectoryCount = Utils::byteArrayToInt(maxDirectoryCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxSIBlockCountByteArray.push_back(byteArray[i]);
	}
	maxSIBlockCount = Utils::byteArrayToInt(maxSIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDIBlockCountByteArray.push_back(byteArray[i]);
	}
	maxDIBlockCount = Utils::byteArrayToInt(maxDIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxTIBlockCountByteArray.push_back(byteArray[i]);
	}
	maxTIBlockCount = Utils::byteArrayToInt(maxTIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDirectoryBlockCountByteArray.push_back(byteArray[i]);
	}
	maxDirectoryBlockCount = Utils::byteArrayToInt(maxDirectoryBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDataBlockCountByteArray.push_back(byteArray[i]);
	}
	maxDataBlockCount = Utils::byteArrayToInt(maxDataBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxFileSizeByteArray.push_back(byteArray[i]);
	}
	maxFileSize = Utils::byteArrayToInt(maxFileSizeByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDirectorySizeByteArray.push_back(byteArray[i]);
	}
	maxDirectorySize = Utils::byteArrayToInt(maxDirectorySizeByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		iNodeStartPosByteArray.push_back(byteArray[i]);
	}
	iNodeStartPos = Utils::byteArrayToInt(iNodeStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		directoryBlockStartPosByteArray.push_back(byteArray[i]);
	}
	directoryBlockStartPos = Utils::byteArrayToInt(directoryBlockStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		dataBlockStartPosByteArray.push_back(byteArray[i]);
	}
	dataBlockStartPos = Utils::byteArrayToInt(dataBlockStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		SIBlockStartPosByteArray.push_back(byteArray[i]);
	}
	SIBlockStartPos = Utils::byteArrayToInt(SIBlockStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		DIBlockStartPosByteArray.push_back(byteArray[i]);
	}
	DIBlockStartPos = Utils::byteArrayToInt(DIBlockStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		TIBlockStartPosByteArray.push_back(byteArray[i]);
	}
	TIBlockStartPos = Utils::byteArrayToInt(TIBlockStartPosByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeDataBlockCountByteArray.push_back(byteArray[i]);
	}
	freeDataBlockCount = Utils::byteArrayToInt(freeDataBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeDirectoryBlockCountByteArray.push_back(byteArray[i]);
	}
	freeDirectoryBlockCount = Utils::byteArrayToInt(freeDirectoryBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeSIBlockCountByteArray.push_back(byteArray[i]);
	}
	freeSIBlockCount = Utils::byteArrayToInt(freeSIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeDIBlockCountByteArray.push_back(byteArray[i]);
	}
	freeDIBlockCount = Utils::byteArrayToInt(freeDIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeTIBlockCountByteArray.push_back(byteArray[i]);
	}
	freeTIBlockCount = Utils::byteArrayToInt(freeTIBlockCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		freeINodeCountByteArray.push_back(byteArray[i]);
	}
	freeINodeCount = Utils::byteArrayToInt(freeINodeCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		currentFileCountByteArray.push_back(byteArray[i]);
	}
	currentFileCount = Utils::byteArrayToInt(currentFileCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		currentDirectoryCountByteArray.push_back(byteArray[i]);
	}
	currentDirectoryCount = Utils::byteArrayToInt(currentDirectoryCountByteArray);
	pos+=4;

	for(int i = pos; i < pos+4; i++){
		maxDirectoryEntryPerDirectoryBlockByteArray.push_back(byteArray[i]);
	}
	maxDirectoryEntryPerDirectoryBlock = Utils::byteArrayToInt(maxDirectoryEntryPerDirectoryBlockByteArray);
	pos+=4;

	pos+= ((1024*blockSize)-pos);


}