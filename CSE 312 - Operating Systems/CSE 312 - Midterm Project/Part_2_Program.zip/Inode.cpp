#include "Inode.h"

Inode::Inode(int iNodeNumber){
	for(int i = 0 ; i < 2 ; i++){
		blockPointers[i] = -1;
	}

	singleIndirectPointer = -1;
	doubleIndirectPointer = -1;
	tripleIndirectPointer = -1;
	attributes.setInodeNum(iNodeNumber);
	attributes.setINodeType(INodeType::Free);
	char str[50] = "";
	attributes.setName(str);
}

void Inode::convertFromByteArray(std::vector<unsigned char> byteArray){
	Superblock *sb = FileSystem::get()->getSuperblock();
	int pos = 0;
	std::vector<unsigned char> typeByteArray;
	std::vector<unsigned char> iNodeNumberByteArray;
	std::vector<unsigned char> linkCountByteArray;
	std::vector<unsigned char> isFreeByteArray;
	std::vector<unsigned char> sizeByteArray;
	std::vector<unsigned char> dayByteArray;
	std::vector<unsigned char> monthByteArray;
	std::vector<unsigned char> yearByteArray;
	std::vector<unsigned char> hourByteArray;
	std::vector<unsigned char> minuteByteArray;
	std::vector<unsigned char> secondByteArray;
	std::vector<unsigned char> filenameByteArray;
	std::vector<unsigned char> blockPointer1ByteArray;
	std::vector<unsigned char> blockPointer2ByteArray;
	std::vector<unsigned char> SIPointerByteArray;
	std::vector<unsigned char> DIPointerByteArray;
	std::vector<unsigned char> TIPointerByteArray;

	for(int i = pos ; i < pos+4 ; i++){
		typeByteArray.push_back(byteArray[i]);
	}
	attributes.setINodeType((INodeType)Utils::byteArrayToInt(typeByteArray));
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		iNodeNumberByteArray.push_back(byteArray[i]);
	}
	attributes.setInodeNum(Utils::byteArrayToInt(iNodeNumberByteArray));
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		linkCountByteArray.push_back(byteArray[i]);
	}
	attributes.setLinkCount(Utils::byteArrayToInt(linkCountByteArray));
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		isFreeByteArray.push_back(byteArray[i]);
	}
	attributes.setIsFree(Utils::byteArrayToInt(isFreeByteArray));
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		sizeByteArray.push_back(byteArray[i]);
	}
	attributes.setSize(Utils::byteArrayToInt(sizeByteArray));
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		dayByteArray.push_back(byteArray[i]);
	}
	int day = Utils::byteArrayToInt(dayByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		monthByteArray.push_back(byteArray[i]);
	}
	int month = Utils::byteArrayToInt(monthByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		yearByteArray.push_back(byteArray[i]);
	}
	int year = Utils::byteArrayToInt(yearByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		hourByteArray.push_back(byteArray[i]);
	}
	int hour = Utils::byteArrayToInt(hourByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		minuteByteArray.push_back(byteArray[i]);
	}
	int minute = Utils::byteArrayToInt(minuteByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		secondByteArray.push_back(byteArray[i]);
	}
	int second = Utils::byteArrayToInt(secondByteArray);
	pos+=4;

	int strPos = 0;
	char fileName[50];
	for(int i = pos ; i < pos+50 ; i++, strPos++){
		fileName[strPos] = byteArray[i];
	}
	pos+=50;

	attributes.setName(fileName);

	for(int i = pos ; i < pos+4 ; i++){
		blockPointer1ByteArray.push_back(byteArray[i]);
	}
	blockPointers[0] = Utils::byteArrayToInt(blockPointer1ByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		blockPointer2ByteArray.push_back(byteArray[i]);
	}
	blockPointers[1] = Utils::byteArrayToInt(blockPointer2ByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		SIPointerByteArray.push_back(byteArray[i]);
	}
	singleIndirectPointer = Utils::byteArrayToInt(SIPointerByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		DIPointerByteArray.push_back(byteArray[i]);
	}
	doubleIndirectPointer = Utils::byteArrayToInt(DIPointerByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		TIPointerByteArray.push_back(byteArray[i]);
	}
	tripleIndirectPointer = Utils::byteArrayToInt(TIPointerByteArray);
	pos+=4;

	pos+= ((1024*sb->getBlockSize())-114);

	struct tm time;
	time.tm_mday = day;
	time.tm_mon = month - 1;
	time.tm_year = year - 1900;
	time.tm_hour = hour;
	time.tm_min = minute;
	time.tm_sec = second;
	time_t date = mktime(&time);
	attributes.setLastModification(date);
}

std::vector<unsigned char> Inode::convertToByteArray(){
	std::vector<unsigned char> content;

	for (auto& byte : attributes.toByteArray()) {
		content.push_back(byte);		
	}

	for(int i = 0 ; i < 2 ; i++){
		for (auto& byte : Utils::intToByteArray(blockPointers[i])) {
			content.push_back(byte);		
		}
	}
	for (auto& byte : Utils::intToByteArray(singleIndirectPointer)) {
		content.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(doubleIndirectPointer)) {
		content.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(tripleIndirectPointer)) {
		content.push_back(byte);		
	}

	Superblock * sb = FileSystem::get()->getSuperblock();
	for(int i = 0 ; i < (1024*sb->getBlockSize())-114 ; i++){
		content.push_back('\0');
	}
	
	return content;

}	

void Inode::assign(char * fileName,	INodeType type){

	FileSystem * fs = FileSystem::get();
	Superblock * sb = FileSystem::get()->getSuperblock();
	if(attributes.getIsFree() == false){
		std::cout << "This i-node is taken" << std::endl;
		return;
	}
	if(sb->getFileCount() >= sb->getMaxFileCount() && type == INodeType::File){
		std::cout << "Cannot create more files" << std::endl;
		return;
	}
	if(sb->getDirectoryCount() >= sb->getMaxDirectoryCount() && type == INodeType::Directory){
		std::cout << "Cannot create more directories" << std::endl;
		return;
	}

	attributes.setSize(0);
	attributes.setName(fileName);
	attributes.setLastModification(time(NULL));
	attributes.setIsFree(false);
	attributes.setLinkCount(attributes.getLinkCount()+1);
	attributes.setINodeType(type);


	sb->setFreeINodeCount(sb->getFreeINodeCount() - 1);
	sb->setFreeSIBlockCount(sb->getFreeSIBlockCount() - 7);
	sb->setFreeDIBlockCount(sb->getFreeDIBlockCount() - 3);
	sb->setFreeTIBlockCount(sb->getFreeTIBlockCount() - 1);

	int nextFreeDirectory = sb->getDirectoryCount();
	int nextFreeFile = sb->getFileCount();

	int dataBlockStartAddr = sb->getDataBlockStartPos();
	int SIBlockStartAddr = sb->getSIBlockStartPos();
	int DIBlockStartAddr = sb->getDIBlockStartPos();
	int TIBlockStartAddr = sb->getTIBlockStartPos();
	int directoryBlockStartAddr = sb->getDirectoryBlockStartPos();

	if(type == INodeType::File){
		blockPointers[0] = 16 * nextFreeFile;
		blockPointers[1] = 16 * nextFreeFile + 1;	
		sb->setFreeDataBlockCount(sb->getFreeDataBlockCount() - 16);
		sb->setFileCount(sb->getFileCount() + 1);
	
	}
	if(type == INodeType::Directory){
		blockPointers[0] = 16 * nextFreeDirectory;
		blockPointers[1] = 16 * nextFreeDirectory + 1;
		sb->setFreeDirectoryBlockCount(sb->getFreeDirectoryBlockCount() - 16);
		sb->setDirectoryCount(sb->getDirectoryCount() + 1);

	}

	
	singleIndirectPointer = 7 * (nextFreeDirectory + nextFreeFile) ;
	doubleIndirectPointer = 3 * (nextFreeDirectory + nextFreeFile);
	tripleIndirectPointer = (nextFreeDirectory + nextFreeFile);

	//Single Indirect Block initialization
	SingleIndirectBlock *sib = fs->getSIBlock(singleIndirectPointer);
	sib->initialize(blockPointers[0] + 2 , blockPointers[0] + 3);

	//Double Indirect Block and its Single Indirect Block's initialization
	DoubleIndirectBlock * dib = fs->getDIBlock(doubleIndirectPointer);
	dib->initialize(7 * attributes.getInodeNum() + 1, 7 * attributes.getInodeNum() + 2);
	

	SingleIndirectBlock *sib1 = fs->getSIBlock(dib->getSIBlock1Addr());
	sib1->initialize(blockPointers[0] + 4 , blockPointers[0] + 5);
	

	SingleIndirectBlock *sib2 = fs->getSIBlock(dib->getSIBlock2Addr());
	sib2->initialize(blockPointers[0] + 6, blockPointers[0] + 7);
	

	//Triple Indirect Block and its Double and Single Indirect Block's initialzation
	TripleIndirectBlock * tib = fs->getTIBlock(tripleIndirectPointer);
	tib->initialize(3 * attributes.getInodeNum() + 1 , 3 * attributes.getInodeNum() + 2);


	DoubleIndirectBlock *dib1 = fs->getDIBlock(tib->getDIBlock1Addr());
	dib1->initialize(7 * attributes.getInodeNum() + 3, 7 * attributes.getInodeNum() + 4);
	
	SingleIndirectBlock *sib3 = fs->getSIBlock(dib1->getSIBlock1Addr());
	sib3->initialize(blockPointers[0] + 8, blockPointers[0] + 9);
	

	SingleIndirectBlock *sib4 = fs->getSIBlock(dib1->getSIBlock2Addr());
	sib4->initialize(blockPointers[0] + 10, blockPointers[0] + 11);


	DoubleIndirectBlock *dib2 = fs->getDIBlock(tib->getDIBlock2Addr());
	dib2->initialize(7 * attributes.getInodeNum() + 5, 7 * attributes.getInodeNum() + 6);
	

	SingleIndirectBlock *sib5 = fs->getSIBlock(dib2->getSIBlock1Addr());
	sib5->initialize(blockPointers[0] + 12, blockPointers[0] + 13);
	

	SingleIndirectBlock *sib6 = fs->getSIBlock(dib2->getSIBlock2Addr());
	sib6->initialize(blockPointers[0] + 14, blockPointers[0] + 15);

	if(type == INodeType::File){
		fs->getDataBlock(blockPointers[0])->setIsFree(false);
		fs->getDataBlock(blockPointers[1])->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 2)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 3)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 4)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 5)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 6)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 7)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 8)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 9)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 10)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 11)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 12)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 13)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 14)->setIsFree(false);
		fs->getDataBlock(blockPointers[0] + 15)->setIsFree(false);
	
	}
	if(type == INodeType::Directory){
		fs->getDirectoryBlock(blockPointers[0])->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[1])->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 2)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 3)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 4)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 5)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 6)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 7)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 8)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 9)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 10)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 11)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 12)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 13)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 14)->setIsFree(false);
		fs->getDirectoryBlock(blockPointers[0] + 15)->setIsFree(false);
	}


}

void Inode::print(){
	
	std::cout << "------------------------------------INODE------------------------------------" << std::endl;
	FileSystem * fs = FileSystem::get();
	Superblock * sb = fs->getSuperblock();
	int startAddr;
	if(attributes.getINodeType() == INodeType::Directory){
		std::cout << "INodeType: Directory"  << std::endl;		
		startAddr = sb->getDirectoryBlockStartPos();
	}
	else if(attributes.getINodeType() == INodeType::File){
		std::cout << "INodeType: File" << std::endl;
		startAddr = sb->getDataBlockStartPos();
	}
	else{
		std::cout << "INodeType: Free" << std::endl;
		startAddr = 0;
	}

	std::string blockTypeString = (attributes.getINodeType() == INodeType::Directory) ? "DIRECTORY BLOCKS" : "DATA BLOCKS";

	std::cout << "INodeNum: " << attributes.getInodeNum() << std::endl;
	std::cout << "linkCount: " << attributes.getLinkCount() << std::endl;
	std::cout << std::boolalpha;
	std::cout << "isFree: " << attributes.getIsFree() << std::endl;
	std::cout << "Size: " << attributes.getSize() << std::endl;
	time_t time = attributes.getLastModification();

	std::cout << "Modification date: " << asctime(localtime(&time));
	std::cout << "Name: " << attributes.getName() << std::endl;
	std::cout << "BlockPointer1: " << startAddr + blockPointers[0] << std::endl;
	std::cout << "BlockPointer2: " << startAddr + blockPointers[1] << std::endl;

	if(attributes.getINodeType() != INodeType::Free){
		std::cout << "SIP: " << sb->getSIBlockStartPos() + singleIndirectPointer << std::endl;
		std::cout << "DIP: " << sb->getDIBlockStartPos() + doubleIndirectPointer<< std::endl;
		std::cout << "TIP: " << sb->getTIBlockStartPos() + tripleIndirectPointer << std::endl;
	}
	else{
		std::cout << "SIP: " << singleIndirectPointer << std::endl;
		std::cout << "DIP: " << doubleIndirectPointer<< std::endl;
		std::cout << "TIP: " << tripleIndirectPointer << std::endl;
	}
	std::cout << "-----------------------------------------------------------------------------" << std::endl;
}
Inode::~Inode() {
   
}

std::vector<int> Inode::allBlockAddresses(){
	std::vector<int> blockAddresses;
	blockAddresses.push_back(blockPointers[0]);
	blockAddresses.push_back(blockPointers[1]);
	blockAddresses.push_back(blockPointers[0] + 2);
	blockAddresses.push_back(blockPointers[0] + 3);
	blockAddresses.push_back(blockPointers[0] + 4);
	blockAddresses.push_back(blockPointers[0] + 5);
	blockAddresses.push_back(blockPointers[0] + 6);
	blockAddresses.push_back(blockPointers[0] + 7);
	blockAddresses.push_back(blockPointers[0] + 8);
	blockAddresses.push_back(blockPointers[0] + 9);
	blockAddresses.push_back(blockPointers[0] + 10);
	blockAddresses.push_back(blockPointers[0] + 11);
	blockAddresses.push_back(blockPointers[0] + 12);
	blockAddresses.push_back(blockPointers[0] + 13);
	blockAddresses.push_back(blockPointers[0] + 14);
	blockAddresses.push_back(blockPointers[0] + 15);
	
	return blockAddresses;
}

void Inode::unassign(){
	FileSystem *fs = FileSystem::get();
	if(attributes.getINodeType() == INodeType::File){
		fs->getDataBlock(blockPointers[0])->reset();
		fs->getDataBlock(blockPointers[1])->reset();
		fs->getDataBlock(blockPointers[0]+2)->reset();
		fs->getDataBlock(blockPointers[0]+3)->reset();
		fs->getDataBlock(blockPointers[0]+4)->reset();
		fs->getDataBlock(blockPointers[0]+5)->reset();
		fs->getDataBlock(blockPointers[0]+6)->reset();
		fs->getDataBlock(blockPointers[0]+7)->reset();
		fs->getDataBlock(blockPointers[0]+8)->reset();
		fs->getDataBlock(blockPointers[0]+9)->reset();
		fs->getDataBlock(blockPointers[0]+10)->reset();
		fs->getDataBlock(blockPointers[0]+11)->reset();
		fs->getDataBlock(blockPointers[0]+12)->reset();
		fs->getDataBlock(blockPointers[0]+13)->reset();
		fs->getDataBlock(blockPointers[0]+14)->reset();
		fs->getDataBlock(blockPointers[0]+15)->reset();

	}
	if(attributes.getINodeType() == INodeType::Directory){
		fs->getDirectoryBlock(blockPointers[0])->reset();
		fs->getDirectoryBlock(blockPointers[1])->reset();
		fs->getDirectoryBlock(blockPointers[0]+2)->reset();
		fs->getDirectoryBlock(blockPointers[0]+3)->reset();
		fs->getDirectoryBlock(blockPointers[0]+4)->reset();
		fs->getDirectoryBlock(blockPointers[0]+5)->reset();
		fs->getDirectoryBlock(blockPointers[0]+6)->reset();
		fs->getDirectoryBlock(blockPointers[0]+7)->reset();
		fs->getDirectoryBlock(blockPointers[0]+8)->reset();
		fs->getDirectoryBlock(blockPointers[0]+9)->reset();
		fs->getDirectoryBlock(blockPointers[0]+10)->reset();
		fs->getDirectoryBlock(blockPointers[0]+11)->reset();
		fs->getDirectoryBlock(blockPointers[0]+12)->reset();
		fs->getDirectoryBlock(blockPointers[0]+13)->reset();
		fs->getDirectoryBlock(blockPointers[0]+14)->reset();
		fs->getDirectoryBlock(blockPointers[0]+15)->reset();
	}
	SingleIndirectBlock * sib = fs->getSIBlock(singleIndirectPointer);
	sib->initialize(-1,-1);
	sib->setIsFree(true);

	DoubleIndirectBlock * dib = fs->getDIBlock(doubleIndirectPointer);
	SingleIndirectBlock *sib1 = fs->getSIBlock(dib->getSIBlock1Addr());
	SingleIndirectBlock *sib2 = fs->getSIBlock(dib->getSIBlock2Addr());
	sib1->initialize(-1,-1);
	sib1->setIsFree(true);
	sib2->initialize(-1,-1);
	sib2->setIsFree(true);
	dib->initialize(-1,-1);
	dib->setIsFree(true);

	TripleIndirectBlock *tib = fs->getTIBlock(tripleIndirectPointer);
	DoubleIndirectBlock *dib1 = fs->getDIBlock(tib->getDIBlock1Addr());
	SingleIndirectBlock *sib3 = fs->getSIBlock(dib1->getSIBlock1Addr());
	SingleIndirectBlock *sib4 = fs->getSIBlock(dib1->getSIBlock2Addr());
	sib3->initialize(-1,-1);
	sib3->setIsFree(true);
	sib4->initialize(-1,-1);
	sib4->setIsFree(true);
	dib1->initialize(-1,-1);
	dib1->setIsFree(true);

	DoubleIndirectBlock *dib2 = fs->getDIBlock(tib->getDIBlock2Addr());
	SingleIndirectBlock *sib5 = fs->getSIBlock(dib2->getSIBlock1Addr());
	SingleIndirectBlock *sib6 = fs->getSIBlock(dib2->getSIBlock2Addr());
	sib5->initialize(-1,-1);
	sib5->setIsFree(true);
	sib6->initialize(-1,-1);
	sib6->setIsFree(true);
	dib2->initialize(-1,-1);
	dib2->setIsFree(true);

	tib->initialize(-1,-1);
	tib->setIsFree(true);

	blockPointers[0] = -1;
	blockPointers[1] = -1;
	singleIndirectPointer = -1;
	doubleIndirectPointer = -1;
	tripleIndirectPointer = -1;

	attributes.clear();
}