#ifndef UTILS_H_
#define UTILS_H_

#include <vector>
#include <iostream>
#include <stdio.h>

class Utils
{
public:
	static std::vector<unsigned char> intToByteArray(int number);
	static int byteArrayToInt(std::vector<unsigned char> byteArray);
};
#endif

