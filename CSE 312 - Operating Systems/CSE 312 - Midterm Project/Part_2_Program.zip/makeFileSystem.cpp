#include "Attribute.h"
#include "Inode.h"
#include "INodeType.h"
#include "FileSystem.h"
#include "DirectoryEntry.h"
#include <cstdio>
#include <iostream>

int main(int argc, char const *argv[])
{
	if(argc != 4){
		std::cout << "Usage: makeFileSystem <blockSize> <freeINodeCount> <diskFileName>" << std::endl;
		return -1;
	}
	int blockSize = atoi(argv[1]);
	int freeINodeCount = atoi(argv[2]);
	char diskFileName[50];
	strcpy(diskFileName,argv[3]);


	FileSystem * fs = FileSystem::get();

	fs->initialize(blockSize,freeINodeCount);
	fs->writeToDisk(diskFileName);
	


	return 0;
}