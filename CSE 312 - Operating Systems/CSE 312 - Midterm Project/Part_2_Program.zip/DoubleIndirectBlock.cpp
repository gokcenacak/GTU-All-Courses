#include "DoubleIndirectBlock.h"

DoubleIndirectBlock::DoubleIndirectBlock(){
	SIBlock1Addr = -1;
	SIBlock2Addr = -1;
	isFree = true;
}
void DoubleIndirectBlock::initialize(int addr1, int addr2){
	SIBlock1Addr = addr1;
	SIBlock2Addr = addr2;
	isFree = false;
}

std::vector<unsigned char> DoubleIndirectBlock::convertToByteArray(){
	int totalBytes = 0;
	std::vector<unsigned char> content;
	for(auto& byte : Utils::intToByteArray(SIBlock1Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(SIBlock2Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(isFree)){
		content.push_back(byte);
		totalBytes++;
	}
	Superblock * sb = FileSystem::get()->getSuperblock();
	for(int i = 0 ; i < (1024*sb->getBlockSize())- totalBytes ; i++){
		content.push_back('\0');
	}
	return content;
}

void DoubleIndirectBlock::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> SIBlock1AddrByteArray;
	std::vector<unsigned char> SIBlock2AddrByteArray;
	std::vector<unsigned char> isFreeByteArray;
	int pos = 0;
	for(int i = pos ; i < pos+4 ; i++){
		SIBlock1AddrByteArray.push_back(byteArray[i]);
	}
	SIBlock1Addr = Utils::byteArrayToInt(SIBlock1AddrByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		SIBlock2AddrByteArray.push_back(byteArray[i]);
	}
	SIBlock2Addr = Utils::byteArrayToInt(SIBlock2AddrByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		isFreeByteArray.push_back(byteArray[i]);
	}
	isFree = Utils::byteArrayToInt(isFreeByteArray);
}
void DoubleIndirectBlock::print(){
	std::cout << "Single Indirect Block Address 1: " << SIBlock1Addr << std::endl;
	std::cout << "Single Indirect Block Address 2: " << SIBlock2Addr << std::endl;
	std::cout << "Is Free: " << isFree << std::endl;
}