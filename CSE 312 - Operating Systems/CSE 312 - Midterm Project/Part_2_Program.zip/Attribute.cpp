#include "Attribute.h"

Attribute::Attribute(){
	size = -1;
	memset(name, '\0', 50);
	lastModification = -1;
	isFree = true;
	linkCount = 0;
	type = INodeType::Free;
}

Attribute::~Attribute(){
	
}

void Attribute::clear() {
	size = -1;
	memset(name, '\0', 50);
	lastModification = -1;
	isFree = true;
	linkCount = 0;
	type = INodeType::Free;
}

std::vector<unsigned char> Attribute::toByteArray(){	

	std::vector<unsigned char> result;

	tm * time = localtime(&lastModification);

	int day = time->tm_mday;
	int month = time->tm_mon + 1;
	int year = 1900+time->tm_year;
	int hour = time->tm_hour;
	int minute = time->tm_min;
	int second = time->tm_sec;

	for (auto& byte : Utils::intToByteArray((int)type)) {
		result.push_back(byte);		
	}

	for (auto& byte : Utils::intToByteArray(iNodeNum)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(linkCount)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray((int)isFree)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(size)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(day)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(month)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(year)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(hour)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(minute)) {
		result.push_back(byte);		
	}
	for (auto& byte : Utils::intToByteArray(second)) {
		result.push_back(byte);		
	}

	for(int i = 0 ; i < 50 ; i++){
		result.push_back(name[i]);
	}
	
	return result;
}
