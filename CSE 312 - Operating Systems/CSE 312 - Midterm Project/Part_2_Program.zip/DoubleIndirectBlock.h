#ifndef DOUBLEINDIRECTBLOCK_H_
#define DOUBLEINDIRECTBLOCK_H_

#include <vector> 
#include "FileSystem.h"
#include "Utils.h"

class DoubleIndirectBlock
{
public:
	DoubleIndirectBlock();
	~DoubleIndirectBlock() {}
	inline int getSIBlock1Addr() { return SIBlock1Addr; }
	inline int getSIBlock2Addr() { return SIBlock2Addr; }
	inline bool getIsFree() 	 { return isFree; }
	inline void setIsFree(bool freeCond) { isFree = freeCond; }
	void initialize(int addr1, int addr2);
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	void print();

private:
	int SIBlock1Addr;
	int SIBlock2Addr;
	bool isFree;
};
#endif

