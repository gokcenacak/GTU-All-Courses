#include "DirectoryBlock.h"
DirectoryBlock::DirectoryBlock(){
	dirEntries.resize(FileSystem::get()->getSuperblock()->getMaxDirectoryEntryPerDirectoryBlock());
	isFull=false;
	isFree = true;
	currentEntryCount = 0;
	maxEntryCount = FileSystem::get()->getSuperblock()->getMaxDirectoryEntryPerDirectoryBlock();
}

DirectoryBlock::~DirectoryBlock(){

}

bool DirectoryBlock::addEntry(DirectoryEntry entry){
	if(isFull){
		std::cout << "Directory block full, cannot add new entry" << std::endl;
		return false;
	}
	else{
		dirEntries[currentEntryCount] = entry;
		currentEntryCount += 1;
		if(currentEntryCount == maxEntryCount){
			isFull = true;
		}
		return true;
	}
}
void DirectoryBlock::print(){
	std::cout << "Maximum Entry Count: " << maxEntryCount << std::endl;
	std::cout << "Current Entry Count: " << currentEntryCount << std::endl;
	std::cout << "Is Full: " << isFull << std::endl;
	std::cout << "Is Free: " << isFree << std::endl;
	/*std::cout << "Entries:" << std::endl;
	for(int i = 0 ; i < dirEntries.size() ; i++){
		std::cout << dirEntries[i].getFileName() << " " <<dirEntries[i].getINodeNumber() << std::endl;
	}*/
	std::cout << "-----------------------------------------------------------------------------" << std::endl;

}

std::vector<unsigned char> DirectoryBlock::convertToByteArray(){
	std::vector<unsigned char> content;
	int totalBytes = 0;
	for(auto& byte: Utils::intToByteArray(maxEntryCount)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte: Utils::intToByteArray(currentEntryCount)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte: Utils::intToByteArray(isFull)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte: Utils::intToByteArray(isFree)){
		content.push_back(byte);
		totalBytes++;
	}
	for(int i = 0 ; i < dirEntries.size() ; i++){
		for(auto& byte: dirEntries[i].convertToByteArray()){
			content.push_back(byte);
			totalBytes++;
		}
	}
	Superblock *sb = FileSystem::get()->getSuperblock();
	for(int i = 0; i < (1024*sb->getBlockSize())- totalBytes; i++){
		content.push_back('\0');
	}
	return content;

}
void DirectoryBlock::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> maxEntryCountByteArray;
	std::vector<unsigned char> currentEntryCountByteArray;
	std::vector<unsigned char> isFullByteArray;
	std::vector<unsigned char> isFreeByteArray;

	int pos = 0;
	for(int i = pos ; i < pos+4 ; i++){
		maxEntryCountByteArray.push_back(byteArray[i]);
	}
	maxEntryCount = Utils::byteArrayToInt(maxEntryCountByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		currentEntryCountByteArray.push_back(byteArray[i]);
	}
	currentEntryCount = Utils::byteArrayToInt(currentEntryCountByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		isFullByteArray.push_back(byteArray[i]);
	}
	isFull = Utils::byteArrayToInt(isFullByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		isFreeByteArray.push_back(byteArray[i]);
	}
	isFree = Utils::byteArrayToInt(isFreeByteArray);
	pos+=4;

	Superblock *sb = FileSystem::get()->getSuperblock();
	std::vector<unsigned char> entryTempByteArray;

	for(int i = 0; i < sb->getMaxDirectoryEntryPerDirectoryBlock() ; i++){
		for(int j = pos; j < pos+54; j++){
			entryTempByteArray.push_back(byteArray[j]);
		}
		pos+=54;
		dirEntries[i].convertFromByteArray(entryTempByteArray);
		entryTempByteArray.clear();
	}

}

DirectoryEntry * DirectoryBlock::findDirectoryEntry(char * name){
	for(int i = 0; i < dirEntries.size(); i++){
		if(strcmp(name,dirEntries[i].getFileName()) == 0){
			return &dirEntries[i];
		}
	}
	return nullptr;
}

void DirectoryBlock::reset(){
	dirEntries.clear();
	dirEntries.resize(FileSystem::get()->getSuperblock()->getMaxDirectoryEntryPerDirectoryBlock());
	isFull = false;
	isFree = true;
	currentEntryCount = 0;
	maxEntryCount = FileSystem::get()->getSuperblock()->getMaxDirectoryEntryPerDirectoryBlock();
}

void DirectoryBlock::removeEntry(DirectoryEntry * entry){
	for(auto dirEntry: dirEntries){
		if(strcmp(dirEntry.getFileName(),entry->getFileName()) == 0 && dirEntry.getINodeNumber() == entry->getINodeNumber()){
			dirEntry.clear();
		}
	}

}