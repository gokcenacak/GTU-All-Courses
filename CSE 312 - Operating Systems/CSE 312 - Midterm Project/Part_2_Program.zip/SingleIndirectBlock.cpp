#include "SingleIndirectBlock.h"

SingleIndirectBlock::SingleIndirectBlock(){ 
	isFree = true; 
	block1Addr = -1;
	block2Addr = -1;
}
void SingleIndirectBlock::initialize(int addr1, int addr2){
	block1Addr = addr1;
	block2Addr = addr2;
	isFree = false;
}

std::vector<unsigned char> SingleIndirectBlock::convertToByteArray(){
	int totalBytes = 0;
	std::vector<unsigned char> content;
	for(auto& byte : Utils::intToByteArray(block1Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(block2Addr)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(isFree)){
		content.push_back(byte);
		totalBytes++;
	}
	Superblock * sb = FileSystem::get()->getSuperblock();
	for(int i = 0 ; i < (1024*sb->getBlockSize())- totalBytes ; i++){
		content.push_back('\0');
	}
	return content;
}

void SingleIndirectBlock::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> block1AddrByteArray;
	std::vector<unsigned char> block2AddrByteArray;
	std::vector<unsigned char> isFreeByteArray;
	int pos = 0;
	for(int i = pos ; i < pos+4 ; i++){
		block1AddrByteArray.push_back(byteArray[i]);
	}
	block1Addr = Utils::byteArrayToInt(block1AddrByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		block2AddrByteArray.push_back(byteArray[i]);
	}
	block2Addr = Utils::byteArrayToInt(block2AddrByteArray);
	pos+=4;
	for(int i = pos ; i < pos+4 ; i++){
		isFreeByteArray.push_back(byteArray[i]);
	}
	isFree = Utils::byteArrayToInt(isFreeByteArray);
}

void SingleIndirectBlock::print(INodeType type){
	if(type == INodeType::File){
		std::cout << "Data Block Address 1: " << block1Addr << std::endl;
		std::cout << "Data Block Address 2: " << block2Addr << std::endl;
		std::cout << "Is Free: " << isFree << std::endl;
	}
	else if(type == INodeType::Directory){
		std::cout << "Directory Block Address 1: " << block1Addr << std::endl;
		std::cout << "Directory Block Address 2: " << block2Addr << std::endl;
		std::cout << "Is Free: " << isFree << std::endl;
	}
	else{
		std::cout << "Block Address 1: " << block1Addr << std::endl;
		std::cout << "Block Address 2: " << block2Addr << std::endl;
		std::cout << "Is Free: " << isFree << std::endl;
	}

}