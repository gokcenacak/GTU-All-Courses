#ifndef SINGLEINDIRECTBLOCK_H_
#define SINGLEINDIRECTBLOCK_H_

#include "FileSystem.h"
#include "Utils.h"
#include "INodeType.h"
class SingleIndirectBlock
{
public:
	SingleIndirectBlock();
	~SingleIndirectBlock() {}
	inline int getBlock1Addr() { return block1Addr; }
	inline int getBlock2Addr() { return block2Addr; }
	inline void setBlock1Addr(int addr) { block1Addr = addr;}
	inline void setBlock2Addr(int addr) { block2Addr = addr;}
	inline bool getIsFree()		{ return isFree; }
	inline void setIsFree(bool freeCond)	{ isFree = freeCond; }
	void initialize(int addr1, int addr2);
	void convertFromByteArray(std::vector<unsigned char> byteArray);
	std::vector<unsigned char> convertToByteArray();
	void print(INodeType type);

private:
	int block1Addr;
	int block2Addr;
	bool isFree;
};
#endif

