#include "DataBlock.h"
DataBlock::DataBlock(){
	size = FileSystem::get()->getSuperblock()->getBlockSize() * 1024 - (3*sizeof(int));
	data.resize(size);
	isFull = false;
	isFree = true;
	occupied = 0;
}

int DataBlock::write(char * dataToWrite, int dataSize){
	int writtenBytes = 0;
	for(int i = 0 ; i < dataSize ; i++){
		if(isFull){
			std::cout << "Data block full, cannot write data" << std::endl;
			return writtenBytes;
		}
		else{
			data[occupied+i] = dataToWrite[i];
			writtenBytes++;
			if(occupied == size){
				isFull = true;
			}
		}
	}
	occupied+=writtenBytes;
	return writtenBytes;
}

void DataBlock::print(){
	std::cout << "Data Capacity: " << size << std::endl;
	std::cout << "Occupied block count: " << occupied << std::endl;
	std::cout << "Is Full: " << isFull << std::endl;
	std::cout << "Is Free: " << isFree << std::endl;
	/*for(int i = 0 ; i < data.size() ; i++){
		std::cout << data[i] ;
	}*/
	std::cout << "-----------------------------------------------------------------------------" << std::endl;

}

std::vector<unsigned char> DataBlock::convertToByteArray(){
	std::vector<unsigned char> content;
	int totalBytes = 0;
	for(auto& byte : Utils::intToByteArray(size)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(occupied)){
		content.push_back(byte);
		totalBytes++;
	}
	for(auto& byte : Utils::intToByteArray(isFull)){
		content.push_back(byte);
		totalBytes++;
	}
	for(int i = 0 ; i < data.size() ; i++){
		content.push_back(data[i]);
		totalBytes++;
	}
	Superblock *sb = FileSystem::get()->getSuperblock();
	for(int i = 0; i < (1024*sb->getBlockSize())-totalBytes; i++){
		content.push_back('\0');
	}
	return content;
}
void DataBlock::convertFromByteArray(std::vector<unsigned char> byteArray){
	std::vector<unsigned char> sizeByteArray;
	std::vector<unsigned char> occupiedByteArray;
	std::vector<unsigned char> isFullByteArray;

	int pos = 0;
	for(int i = pos ; i < pos+4 ; i++){
		sizeByteArray.push_back(byteArray[i]);
	}
	size = Utils::byteArrayToInt(sizeByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		occupiedByteArray.push_back(byteArray[i]);
	}
	occupied = Utils::byteArrayToInt(occupiedByteArray);
	pos+=4;

	for(int i = pos ; i < pos+4 ; i++){
		isFullByteArray.push_back(byteArray[i]);
	}
	isFull = Utils::byteArrayToInt(isFullByteArray);
	pos+=4;

	int arrayPos = 0;
	for(int i = pos; i < data.size(); i++, arrayPos++){
		data[arrayPos] = byteArray[i];
	}

}

void DataBlock::reset(){
	data.clear();
	size = FileSystem::get()->getSuperblock()->getBlockSize() * 1024 - (3*sizeof(int));
	data.resize(size);
	occupied = 0;
	isFull = false;
	isFree = true;
}